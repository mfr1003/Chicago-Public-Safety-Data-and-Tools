# Clearpath

A free, open-source benefits navigator. No login. No tracking. No gatekeeping.

Clearpath helps anyone find the programs and resources available to them, and generates
pre-filled application forms so they walk into the office with most of the work already done.
Sensitive fields (SSN, income, immigration status) are never collected — they appear as
clearly labeled blank lines on printed forms.

---

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Add your Anthropic API key

```bash
cp .env.example .env.local
# Edit .env.local and add your key:
# ANTHROPIC_API_KEY=sk-ant-...
```

Get a key at https://console.anthropic.com

### 3. Run locally

```bash
npm run dev
```

Open http://localhost:3000

---

## Deploy to Vercel (free)

1. Push this repo to GitHub
2. Go to https://vercel.com and import the repo
3. Add environment variable: `ANTHROPIC_API_KEY` = your key
4. Deploy

That's it. Vercel handles everything else for free at meaningful scale.

---

## Project structure

```
pages/
  index.js              — Main app (chat + resources panel)
  api/
    chat.js             — Anthropic API proxy (key stays server-side)
    generate-pdf.js     — Pre-filled PDF generation endpoint
    suggest-form.js     — Community form suggestion endpoint

lib/
  profile.js            — Profile schema and gap detection
  forms/
    index.js            — Form templates (SNAP, Section 8, Medicaid, etc.)
    generatePdf.js      — PDF generator using pdf-lib
```

---

## Adding a new form

In `lib/forms/index.js`, add a new entry to the `FORMS` object:

```js
your_form_id: {
  id: "your_form_id",
  name: "Human readable name",
  category: "food|health|cash|housing|utilities|childcare|employment|banking",
  description: "What this program does",
  states: "all",   // or ["TX", "CA"] for state-specific
  prefill_fields: [
    // Fields from the profile we can fill in — see lib/profile.js for options
    "first_name", "last_name", "state", ...
  ],
  user_must_fill: [
    // Fields the user fills in themselves (sensitive info)
    { label: "Social Security Number", lines: 1 },
    { label: "Monthly income", lines: 1 },
    { label: "Signature", lines: 1 },
  ],
  bring_to_office: [
    "Government-issued photo ID",
    ...
  ],
  how_to_apply: "...",
  office_locator: "https://...",
}
```

Then tell Maya about it by adding the form ID to the list in `pages/api/chat.js`.

---

## Form suggestions

User-submitted form suggestions currently log to the server console.
To store them properly, edit `pages/api/suggest-form.js` and connect to:
- Airtable (recommended for non-technical collaborators)
- GitHub Issues API
- Email via Resend or Postmark

---

## Philosophy

- No login required, ever
- No sensitive data collected or stored
- Session data lives in browser sessionStorage only — gone when the tab closes
- Open source — the privacy promise is verifiable, not just stated
- Forms are preparation aids, not official government documents

---

## Contributing

Issues, PRs, and form additions welcome. The highest-value contributions are:
- New form templates (especially state-specific programs)
- Accuracy reviews of existing program information
- Translations
- Accessibility improvements

---

## Running costs

The only cost to run this is Anthropic API usage.
At current pricing, a full conversation is roughly $0.01–0.03.
At 1,000 monthly users: ~$10–30/month.
At 10,000 monthly users: ~$100–300/month.

A simple "support this project" page or small grants from aligned foundations
can cover this indefinitely.
